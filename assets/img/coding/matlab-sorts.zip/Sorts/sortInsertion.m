function sorted = insertionSort(sortee)
global vectorlength graphson

xaxis = 1:vectorlength;
sorted = sortee;
timersort = tic;
updaterefesh = tic;

for i = 2:vectorlength
    j = i;
    while (j > 1) && (sorted(j-1) > sorted(j))
        sorted([j j-1]) = sorted([j-1 j]);
        j = j-1;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if graphson == true
            bar(xaxis,sorted,'w');
            title('\color{gray}Insertion Sort');
            set(gca,'color','k');
            updatecounter = toc(updaterefesh);
            if updatecounter > (1/30)
                hold on;
                if j-1 > 0
                    bar(j,sorted(j),'r');
                end
                drawnow;
                hold off;
                updaterefesh = tic;
            end
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
end
spent = toc(timersort);
disp(strcat(sprintf('Insertion sort elapsed time is: %f ', spent),' seconds'))

if graphson == true
    bar(xaxis,sorted,'g');
    title('\color{gray}Insertion Sort');
    set(gca,'color','k');
    pause(2)
end

end

