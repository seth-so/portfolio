function sorted = bubbleSort(sortee)
global vectorlength graphson

sorted = sortee;
xaxis = 1:vectorlength;
changes = inf;
timersort = tic;
updaterefesh = tic;

while changes ~= 0
    iterations = 0;
    for i = 1:vectorlength-1
        if sorted(i) > sorted(i+1)
            sorted([i i+1]) = sorted([i+1 i]);
            iterations = i;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if graphson == true
                bar(xaxis,sorted,'w');
                title('\color{gray}Bubble Sort');
                set(gca,'color','k');
                updatecounter = toc(updaterefesh);
                if updatecounter > (1/30)
                    hold on;
                    bar(i+1,sorted(i+1),'r');
                    drawnow;
                    hold off;
                    updaterefesh = tic;
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end
        changes = iterations;
    end
end
spent = toc(timersort);
disp(strcat(sprintf('Bubble Sort elapsed time is: %f ', spent),' seconds'))

if graphson == true
    bar(xaxis,sorted,'g');
    title('\color{gray}Bubble Sort');
    set(gca,'color','k');
    pause(2)
end

end


