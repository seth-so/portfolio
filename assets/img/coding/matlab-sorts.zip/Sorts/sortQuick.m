function [sortee] = sortQuick(sortee)
global vectorlength graphson

if numel(sortee) <= 1
    return
    
else
    pivotA=sortee(floor(length(sortee/2)));
    sortee = [
        sortQuick( sortee(sortee < pivotA))...
        sortee(sortee == pivotA)...
        sortQuick(sortee(sortee > pivotA))
        ];
    
    if graphson == true
        xaxis = sortee;
        pivotB = pivotA;
        bar(xaxis,sortee,'w'); hold on
        title('\color{gray}Quick Sort');
        set(gca,'color','k');
        bar(pivotA,pivotB,'r');
        xlim([0 vectorlength]);ylim([0 vectorlength]);
        drawnow;
    end
end

end