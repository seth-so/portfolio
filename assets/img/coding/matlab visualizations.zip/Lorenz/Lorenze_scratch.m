% x = 1:0.01:25;
% y = sin(x);
% n = numel(x);
% % clf;
% % cla;
% x = x(1:5:end);
% y = y(1:5:end);
% 
% setappdata(gca,'LegendColorbarManualSpace',1);
% setappdata(gca,'LegendColorbarReclaimSpace',1);
% figure
% for i = 1:n
%     plot(x(1:i),y(1:i),'LineWidth', 3)
%     xlim([0 25])
%     ylim([-1.1 1.1])
%     drawnow;
% end

x = 1:1:27;
x = reshape(x,3,3,3);

a = x(:,:,1);
a = a(1:2:end,1:2:end)

b = x(:,:,2);
b = b(1:2:end,1:2:end)

c = x(:,:,3);
c = c(1:2:end,1:2:end)


y = cat(3,a,b,c);