clear all;
close all;
clc;

%display customizations                                                       DEFAULTS
params = [10; 28; 8/3]; %sigma, rho, beta e. g.                            [10; 28; 8/3]
downsample = 7;         %decimation amount (plot rate)                           7 
pointsize = 2;          %plot point size                                         2
markertype = 'o';       %standard markertyping                                  'o'
azStep = 1/15;          %azimuth procession rate                                1/4
azStart = 45;           %azimuth starting angle                                 45
elStep = 0;             %elevation procession rate                               0
elStart = 20;           %elevation starting angle                               20
factorR = 2;            %red colormap weight                                     2
factorG = 9;            %green colormap weight                                   9
factorB = 4;            %blue colormap weight                                    4 

%calculate lorenz system
x0 = [0; 1; 20];        %initial conditions                                  [0; 1; 20]
dt = 0.001;             %timestep                                              0.001
tspan = dt:dt:50;       %timespan                                            dt:dt:50
options = odeset('RelTol', 1e-12, ...  tolerances                             1e-12
                 'AbsTol', 1e-12*ones(1,3)); ...                           1e-12*ones(1,3)   
[t,X] = ode45(@(t,x)lorenz(t,x,params),tspan,x0,options);  %solving

%trimming for live plot
Xdown = normalize(X(1:downsample:end,:));
pointsdraw = length(Xdown);

%colormapping points
colorMap = zeros(pointsdraw,3);
for k = 1:pointsdraw
   colorMap(k,1) = Xdown(k,1)*factorR;
   colorMap(k,2) = Xdown(k,2)*factorG;
   colorMap(k,3) = Xdown(k,3)*factorB;
end
colorMap = abs(normalize(normalize(colorMap)));

%plotting
pointstime = length(t); 
figure('Name','1936 Lorenz Attractor','color','black')
annotation('textbox',[.01 .025 .05 .05],'String','(Pause with Editor)', ...
           'FitBoxToText','on', 'color',[.2 .2 .2], ...
           'FontName','Lucida Fax');
ButtonHandle = uicontrol('Visible', 'off', 'Callback', 'delete(gcbf)');
setappdata(gca,'LegendColorbarManualSpace',1);
setappdata(gca,'LegendColorbarReclaimSpace',1);
refreshtimer = tic;
for i = 1:pointstime
    scatter3(Xdown(1:i,1), Xdown(1:i,2), Xdown(1:i,3), pointsize, colorMap(1:i,:),markertype);
    view(azStart+i*azStep, elStart+i*elStep)
    xlim([-3 3]); ylim([-3 3]); zlim([-3 3]);
    set(gca,'color','k'); title('\color{gray}1936 Lorenz Attractor', 'FontName','Lucida Fax');
    refreshcounter = toc(refreshtimer); %  check timer
    if refreshcounter > (1/30)
        drawnow % update screen every 1/30 seconds
        refreshtimer = tic; % reset timer after updating
    end
    if ~ishandle(ButtonHandle)
       disp('Loop stopped by user');
       break;
    end
end

%Comment out live plot for singular point cloud
%pcshow(X)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function dx = lorenz(t,X,params)
    x = X(1);
    y = X(2);
    z = X(3);
    sigma = params(1);
    rho = params(2);
    beta = params(3);
    dx = [  sigma * (y - x);
            x * (rho - z) - y;
            x * y - beta * z   ];
end

