clear all;
close all;
clc

xvals = [];

for beta = 0:0.01:4
    xold = 0.5;
    for i = 1:2000
        xnew = (xold-xold^2)*beta;
        xold = xnew;
        xvals(1,length(xvals)+1) = beta;
        xvals(2, length(xvals)) = xnew;
    end
end

plot(xvals(1,:),xvals(2,:),'.', 'LineWidth',.5, 'MarkerSize',1.2)
set(gcf,'color','w'); set(gca,'color','w');
xlabel('Rate Beta'); ylabel('Population X'); title('Logistics Map:  x_k_+_1 = Beta*x_k(1-x_k)');
