clc
clear all;
close all;
global vectorlength graphson

setappdata(gca,'LegendColorbarManualSpace',1);
setappdata(gca,'LegendColorbarReclaimSpace',1);
set(gcf,'color','k');

% length = input('Choose how many vectors to sort: ');
% graph = input('Would you like visualizations? (1/0): ');

vectorlength = 150; %75 for graphson, 10k for graphsoff
graphson = true;

for i = 1:1
    sortee = randperm(vectorlength);
    tic
    
    sorted = sortBubble(sortee);       %uncomment for bubble sort
    %sorted = sortInsertion(sortee);    %uncomment for insertion sort
    %sorted = sortQuick(sortee);         %uncomment for quick sort
        if graphson == true
           bar(sorted,sorted,'g');
           title('\color{gray}Quick Sort');
           set(gca,'color','k');
        end    
    toc
    
end

x = 1:1:100;
y = 1:1:100;
rainbowplot(x,y)
set(gca,'color','k')