clear all;
clc;

%Customization
Harmonics = [1 8 32 256 512]; %0 < i < 512
numHarmonics = length(Harmonics);
titletext = sprintf('Fourier SqWave Approximation');
labels = compose('%d',Harmonics);

%define discrete sampling
L = 10;
N = 1024;
dx = L/(N-1);
x = 0:dx:L;

%define square signal
f = zeros(size(x));
f(256:768) = 1;
figure('Name','Gibbs Phenomenom','color','w');
plot(x,f,'r','Linewidth',5); hold on;
xlabel('x val'); ylabel('Frequency');
title(titletext,'color', [.25 .25 .25]);
grid on

%calculate fourier series coefficients
for i = 1:numHarmonics
    A0 = sum(f.*ones(size(x)))*dx*2/L;
    fFs = A0/2;
    for k = 1:Harmonics(i)
        Ak = sum(f.*cos(2*pi*k*x/L))*dx*2/L;
        Bk = sum(f.*sin(2*pi*k*x/L))*dx*2/L;
        fFs = fFs + Ak*cos(2*pi*k*x/L) + Bk*sin(2*pi*k*x/L);
    end
    plot(x,fFs,'-','LineWidth',1.2); hold on
    set(gca,'color','w'); grid on
end 



